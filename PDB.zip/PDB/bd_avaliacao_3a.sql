USE master IF EXISTS( SELECT * FROM SYS.databases
					 WHERE name = 'bd_avaliacao_3A')
DROP DATABASE bd_avaliacao_3A
GO
CREATE DATABASE bd_avaliacao_3A
GO
USE bd_avaliacao_3A

CREATE TABLE Usuario
( 
   id            INT			IDENTITY,
   nome          VARCHAR(100)	NOT NULL,
   email         VARCHAR(100)	UNIQUE NOT NULL,
   senha         VARCHAR(100)	NOT NULL,
   nivelAcesso   VARCHAR(10)    NULL, -- ADMIN,USER(EXPOSITOR OU ALUNO/PROFESSOR AVALIADOR)
   foto			 VARBINARY(MAX) NULL,
   dataCadastro	 SMALLDATETIME	NOT NULL,
   statusUsuario VARCHAR(20)    NOT NULL, -- ATIVO ou INATIVO ou TROCAR_SENHA

   PRIMARY KEY (id)
   );
   GO
INSERT Usuario (nome, email, senha, nivelAcesso, foto, dataCadastro, statusUsuario)
VALUES ('Fulano da Silva', 'fulano@email.com.br', 'MTIzNDU2Nzg=', 'ADMIN', NULL, GETDATE(), 'ATIVO')
INSERT Usuario (nome, email, senha, nivelAcesso, foto, dataCadastro, statusUsuario)
VALUES ('Beltrana de S�', 'beltrana@email.com.br', 'MTIzNDU2Nzg=', 'EXPOSTIOR', NULL, GETDATE(), 'ATIVO')
INSERT Usuario (nome, email, senha, nivelAcesso, foto, dataCadastro, statusUsuario)
VALUES ('Sicrana de Oliveira', 'sicrana@email.com.br', 'MTIzNDU2Nzg=', 'ALUNO', NULL, GETDATE(), 'ATIVO')
INSERT Usuario (nome, email, senha, nivelAcesso, foto, dataCadastro, statusUsuario)
VALUES ('Ordnael Zurc', 'ordnael@email.com.br', 'MTIzNDU2Nzg=', 'PROFESSOR', NULL, GETDATE(), 'ATIVO')
GO

CREATE TABLE Festival (
    id			   INT			  IDENTITY,
    nome		   VARCHAR(50)    NOT NULL,
	datacadastro   DATETIME		  NOT NULL,
    datainicio	   DATETIME		  NOT NULL,
    datafim		   DATETIME		  NOT NULL,
    localfestival  VARCHAR(100)   NOT NULL,
    descricao	   VARCHAR(300)   NULL,
	foto		   VARBINARY(MAX) NULL,
    statusfestival VARCHAR(20)	  NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE Projeto (
    id		    INT IDENTITY,
    nome	    VARCHAR(100)   NOT NULL,
    descricao   VARCHAR(200)   NOT NULL,
    notaprof    DECIMAL(8,2)   NULL,
    notageral   DECIMAL(8,2)   NULL,
	foto		VARBINARY(MAX) NULL,
    festival_id INT			   NOT NULL,
	usuario_id	INT			   NOT NULL,

    statusprojeto VARCHAR(20) NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (festival_id) REFERENCES festival(id),
	 FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

CREATE TABLE Avaliacao (
    id			    INT IDENTITY,
    nota		    DECIMAL(8,2)	NOT NULL,
    comentario      VARCHAR(200)	NULL,
    datadeavaliacao DATETIME		NOT NULL,
    usuario_id		INT				NOT NULL,
    projeto_id		INT				NOT NULL,
	 PRIMARY KEY (id),
    FOREIGN KEY (usuario_id) REFERENCES usuario(id),
    FOREIGN KEY (projeto_id) REFERENCES projeto(id)
);
